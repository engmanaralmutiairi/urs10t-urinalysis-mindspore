import { Router, type IRouter } from "express";
import healthRouter from "./health";
import patientsRouter from "./patients";
import testsRouter from "./tests";
import obsRouter from "./obs";

const router: IRouter = Router();

router.use(healthRouter);
router.use(patientsRouter);
router.use(testsRouter);
router.use(obsRouter);

export default router;
