import { Router, type IRouter } from "express";
import { syncFromObs, getLastSyncResult } from "../services/obs";

const router: IRouter = Router();

router.post("/obs/sync", async (_req, res) => {
  try {
    const result = await syncFromObs();
    return res.json(result);
  } catch (err: any) {
    console.error("[OBS route]", err);
    return res.status(500).json({ error: err?.message ?? "Sync failed" });
  }
});

router.get("/obs/status", (_req, res) => {
  return res.json(getLastSyncResult());
});

export default router;
