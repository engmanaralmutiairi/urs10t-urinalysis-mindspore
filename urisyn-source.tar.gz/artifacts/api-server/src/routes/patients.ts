import { Router, type IRouter } from "express";
import { db, patientsTable, urinalysisTestsTable, insertPatientSchema } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/patients", async (_req, res) => {
  try {
    const patients = await db.select().from(patientsTable).orderBy(desc(patientsTable.createdAt));

    const results = await Promise.all(
      patients.map(async (p) => {
        const latestTest = await db
          .select()
          .from(urinalysisTestsTable)
          .where(eq(urinalysisTestsTable.patientId, p.id))
          .orderBy(desc(urinalysisTestsTable.testDate))
          .limit(1);

        return {
          ...p,
          dateOfBirth: p.dateOfBirth,
          latestTestId: latestTest[0]?.id ?? null,
          latestTestDate: latestTest[0]?.testDate ?? null,
          overallStatus: latestTest[0]?.overallStatus ?? null,
        };
      })
    );

    res.json(results);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/patients", async (req, res) => {
  try {
    const parsed = insertPatientSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid input" });
    }
    const [patient] = await db.insert(patientsTable).values(parsed.data).returning();
    return res.status(201).json(patient);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/patients/:patientId", async (req, res) => {
  try {
    const id = parseInt(req.params.patientId, 10);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid patient ID" });

    const [patient] = await db.select().from(patientsTable).where(eq(patientsTable.id, id));
    if (!patient) return res.status(404).json({ error: "Patient not found" });

    const latestTest = await db
      .select()
      .from(urinalysisTestsTable)
      .where(eq(urinalysisTestsTable.patientId, id))
      .orderBy(desc(urinalysisTestsTable.testDate))
      .limit(1);

    return res.json({
      ...patient,
      latestTestId: latestTest[0]?.id ?? null,
      latestTestDate: latestTest[0]?.testDate ?? null,
      overallStatus: latestTest[0]?.overallStatus ?? null,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/patients/:patientId/tests", async (req, res) => {
  try {
    const patientId = parseInt(req.params.patientId, 10);
    if (isNaN(patientId)) return res.status(400).json({ error: "Invalid patient ID" });

    const tests = await db
      .select()
      .from(urinalysisTestsTable)
      .where(eq(urinalysisTestsTable.patientId, patientId))
      .orderBy(desc(urinalysisTestsTable.testDate));

    return res.json(tests);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
