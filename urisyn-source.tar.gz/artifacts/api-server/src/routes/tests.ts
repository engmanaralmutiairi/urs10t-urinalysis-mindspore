import { Router, type IRouter } from "express";
import { db, urinalysisTestsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { z } from "zod";

const router: IRouter = Router();

const testParameterSchema = z.object({
  pad: z.string(),
  result: z.string(),
  confidencePercent: z.number().int(),
  status: z.enum(["ok", "mild", "critical"]),
  explanation: z.string().nullable().optional(),
});

const createTestSchema = z.object({
  patientId: z.number().int(),
  testDate: z.string(),
  overallStatus: z.enum(["ok", "mild", "critical"]),
  recommendation: z.string(),
  parameters: z.array(testParameterSchema),
  notes: z.string().nullable().optional(),
});

router.get("/tests/:testId", async (req, res) => {
  try {
    const id = parseInt(req.params.testId, 10);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid test ID" });

    const [test] = await db.select().from(urinalysisTestsTable).where(eq(urinalysisTestsTable.id, id));
    if (!test) return res.status(404).json({ error: "Test not found" });

    return res.json(test);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/tests", async (req, res) => {
  try {
    const parsed = createTestSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid input" });
    }

    const [test] = await db
      .insert(urinalysisTestsTable)
      .values({
        patientId: parsed.data.patientId,
        testDate: parsed.data.testDate,
        overallStatus: parsed.data.overallStatus,
        recommendation: parsed.data.recommendation,
        parameters: parsed.data.parameters,
        notes: parsed.data.notes ?? null,
      })
      .returning();

    return res.status(201).json(test);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
