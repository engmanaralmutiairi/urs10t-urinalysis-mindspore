import ObsClient from "esdk-obs-nodejs";
import { db, urinalysisTestsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { patientsTable } from "@workspace/db";

const OBS_ACCESS_KEY = process.env["OBS_ACCESS_KEY"];
const OBS_SECRET_KEY = process.env["OBS_SECRET_KEY"];
const OBS_BUCKET     = process.env["OBS_BUCKET"]   ?? "urinalysis-data-jnb";
const OBS_ENDPOINT   = process.env["OBS_ENDPOINT"] ?? "obs.af-south-1.myhuaweicloud.com";

/* Folder prefix to scan — only files under this path are imported */
const OBS_FOLDER_PREFIX = "results/sara_records/";

/* patient_folder name → patient ID mapping */
const FOLDER_TO_PATIENT: Record<string, string> = {
  sara_records: "MED-2024-001",
};

export interface SyncResult {
  imported: number;
  skipped:  number;
  errors:   string[];
  lastSync: string;
}

let lastSyncResult: SyncResult = {
  imported: 0,
  skipped:  0,
  errors:   [],
  lastSync: "Never",
};

/* ── OBS helpers ── */

function createObsClient(): ObsClient {
  return new ObsClient({
    access_key_id:     OBS_ACCESS_KEY,
    secret_access_key: OBS_SECRET_KEY,
    server: `https://${OBS_ENDPOINT}`,
  });
}

function listObjects(obs: ObsClient, bucket: string, prefix: string): Promise<string[]> {
  return new Promise((resolve, reject) => {
    obs.listObjects(
      { Bucket: bucket, Prefix: prefix },
      (err: Error | null, result: any) => {
        if (err) return reject(err);
        if (result.CommonMsg?.Status >= 300) {
          return reject(
            new Error(`OBS listObjects failed: ${result.CommonMsg.Message} (${result.CommonMsg.Status})`)
          );
        }
        const contents: any[] = result.InterfaceResult?.Contents ?? [];
        const keys = contents
          .map((c: any) => c.Key as string)
          .filter((k) => k.endsWith(".json"));
        resolve(keys);
      }
    );
  });
}

function getObject(obs: ObsClient, bucket: string, key: string): Promise<string> {
  return new Promise((resolve, reject) => {
    obs.getObject(
      { Bucket: bucket, Key: key },
      (err: Error | null, result: any) => {
        if (err) return reject(err);
        if (result.CommonMsg?.Status >= 300) {
          return reject(
            new Error(`OBS getObject failed for ${key}: ${result.CommonMsg.Message}`)
          );
        }
        const body = result.InterfaceResult?.Content ?? "";
        resolve(typeof body === "string" ? body : JSON.stringify(body));
      }
    );
  });
}

/* ── Parsing helpers ── */

/**
 * Extract ISO date from OBS key filename.
 * Supports filenames starting with DDMMYYYY (e.g. 14032026_0550_test.json → 2026-03-14).
 * Falls back to today if no match.
 */
function parseDateFromKey(key: string): string | null {
  const basename = key.split("/").pop() ?? "";
  // Match leading 8-digit block: DDMMYYYY
  const m = basename.match(/^(\d{2})(\d{2})(\d{4})/);
  if (m) {
    const [, dd, mm, yyyy] = m;
    // Basic sanity check
    const day   = parseInt(dd, 10);
    const month = parseInt(mm, 10);
    const year  = parseInt(yyyy, 10);
    if (day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 2000) {
      return `${yyyy}-${mm}-${dd}`;
    }
  }
  return null;
}

/**
 * Convert "14/03/2026" → "2026-03-14"
 */
function parseDdMmYyyy(raw: string): string {
  const parts = raw.split("/");
  if (parts.length === 3) {
    const [dd, mm, yyyy] = parts;
    return `${yyyy}-${mm.padStart(2, "0")}-${dd.padStart(2, "0")}`;
  }
  return new Date().toISOString().slice(0, 10);
}

/**
 * Map AI status strings → DB status enum
 */
function mapStatus(raw: string): "ok" | "mild" | "critical" {
  const s = raw.toUpperCase().trim();
  if (s === "CRITICAL") return "critical";
  if (s === "MILD" || s === "MODERATE") return "mild";
  return "ok";
}

/**
 * Map AI overall severity → DB status enum
 */
function mapOverallStatus(severityLabel: string): "ok" | "mild" | "critical" {
  const s = severityLabel?.toLowerCase() ?? "";
  if (s === "critical") return "critical";
  if (s === "mild" || s === "moderate") return "mild";
  return "ok";
}

/**
 * Build a plain-English explanation for each biomarker.
 */
function buildExplanation(biomarker: any): string {
  if (biomarker.clinical_note) return biomarker.clinical_note;
  const level = biomarker.predicted_level ?? biomarker.result ?? "Unknown";
  const status = mapStatus(biomarker.status ?? "ok");
  if (status === "critical") return `${level} — requires immediate medical attention`;
  if (status === "mild")     return `${level} — slightly outside normal range, worth monitoring`;
  return "Within normal range";
}

/* ── Main import function ── */

async function importFile(obs: ObsClient, key: string): Promise<void> {
  const raw  = await getObject(obs, OBS_BUCKET, key);
  const json = JSON.parse(raw);

  /* Detect format: new AI format has "biomarkers" array */
  if (Array.isArray(json.biomarkers)) {
    await importNewFormat(json, key);
  } else {
    await importLegacyFormat(json, key);
  }
}

/** ── NEW format (AI output with biomarkers[], meta, summary) ── */
async function importNewFormat(json: any, key: string): Promise<void> {
  const meta    = json.meta    ?? {};
  const summary = json.summary ?? {};
  const biomarkers: any[] = json.biomarkers ?? [];

  /* Resolve patient from folder name */
  const folderName = meta.patient_folder ?? "";
  const medicalId  = FOLDER_TO_PATIENT[folderName];
  let patientId    = 1;
  if (medicalId) {
    const [p] = await db.select().from(patientsTable).where(eq(patientsTable.medicalId, medicalId));
    if (p) patientId = p.id;
  }

  /* Date — filename is the source of truth (e.g. 14032026_test.json → 2026-03-14),
     falling back to meta.test_date if the filename doesn't contain a date. */
  const testDate =
    parseDateFromKey(key) ??
    parseDdMmYyyy(meta.test_date ?? "");

  console.log(`[OBS] Date resolved for ${key}: ${testDate}`);

  /* Overall status from summary */
  const overallStatus = mapOverallStatus(summary.overall_severity_label ?? "Normal");

  /* Recommendation from verdict */
  const verdict = summary.verdict ?? "";
  const recommendation = verdict === "VISIT DOCTOR TODAY"
    ? "Critical markers detected. Please see a doctor today."
    : "All values appear within acceptable ranges. Continue monitoring.";

  /* Map biomarkers */
  const parameters = biomarkers.map((b: any) => ({
    pad:               String(b.pad ?? "Unknown"),
    result:            String(b.predicted_level ?? b.result ?? ""),
    confidencePercent: Math.round((b.confidence ?? 0) * 100),
    status:            mapStatus(b.status ?? "OK"),
    explanation:       buildExplanation(b),
  }));

  /* Skip if no real biomarkers (e.g. ML model files) */
  if (parameters.length === 0) {
    console.log(`[OBS] Skipped (no biomarkers): ${key}`);
    return;
  }

  await db.insert(urinalysisTestsTable).values({
    patientId,
    testDate,
    overallStatus,
    recommendation,
    parameters,
    notes: `Imported from ${key} · Platform: ${meta.platform ?? "OBS"}`,
    obsFileKey: key,
  });
}

/** ── LEGACY format (old custom JSON) ── */
async function importLegacyFormat(parsed: any, key: string): Promise<void> {
  function camel(k: string) { return k.replace(/_([a-z])/g, (_, c) => c.toUpperCase()); }
  function norm(obj: Record<string, any>): Record<string, any> {
    const r: Record<string, any> = {};
    for (const [k, v] of Object.entries(obj)) {
      const nk = camel(k);
      r[nk] = Array.isArray(v) ? v.map(i => i && typeof i === "object" ? norm(i) : i)
                : v && typeof v === "object" ? norm(v as Record<string, any>) : v;
    }
    return r;
  }
  const p = norm(parsed);

  let patientId = p["patientId"] ?? 1;
  if (p["medicalId"] || p["patientMedicalId"]) {
    const medId = p["medicalId"] ?? p["patientMedicalId"];
    const [pat] = await db.select().from(patientsTable).where(eq(patientsTable.medicalId, String(medId)));
    if (pat) patientId = pat.id;
  }

  const parameters = (p["parameters"] ?? []).map((param: any) => ({
    pad:               String(param["pad"] ?? param["name"] ?? "Unknown"),
    result:            String(param["result"] ?? param["value"] ?? ""),
    confidencePercent: Number(param["confidencePercent"] ?? param["confidence"] ?? 50),
    status:            (["ok", "mild", "critical"].includes(param["status"]) ? param["status"] : "ok") as "ok" | "mild" | "critical",
    explanation:       param["explanation"] ?? null,
  }));

  if (parameters.length === 0) return;

  const overallStatus = (["ok", "mild", "critical"].includes(p["overallStatus"]) ? p["overallStatus"] : "ok") as "ok" | "mild" | "critical";

  await db.insert(urinalysisTestsTable).values({
    patientId,
    testDate:       p["testDate"] ?? new Date().toISOString().slice(0, 10),
    overallStatus,
    recommendation: p["recommendation"] ?? "Review with your doctor.",
    parameters,
    notes:          p["notes"] ?? null,
    obsFileKey:     key,
  });
}

/* ── Sync orchestration ── */

export async function syncFromObs(): Promise<SyncResult> {
  if (!OBS_ACCESS_KEY || !OBS_SECRET_KEY) {
    const result: SyncResult = {
      imported: 0, skipped: 0,
      errors:   ["OBS credentials not configured"],
      lastSync: new Date().toISOString(),
    };
    lastSyncResult = result;
    return result;
  }

  const obs    = createObsClient();
  const errors: string[] = [];
  let imported = 0;
  let skipped  = 0;

  try {
    const keys = await listObjects(obs, OBS_BUCKET, OBS_FOLDER_PREFIX);
    console.log(`[OBS] Found ${keys.length} JSON file(s) under ${OBS_FOLDER_PREFIX}`);

    /* Already-imported keys */
    const existingRows = await db
      .select({ obsFileKey: urinalysisTestsTable.obsFileKey })
      .from(urinalysisTestsTable);
    const existingSet = new Set(existingRows.map(r => r.obsFileKey).filter(Boolean) as string[]);

    for (const key of keys) {
      if (existingSet.has(key)) {
        skipped++;
        continue;
      }
      try {
        await importFile(obs, key);
        imported++;
        console.log(`[OBS] Imported: ${key}`);
      } catch (err: any) {
        const msg = `Failed to import ${key}: ${err?.message ?? err}`;
        errors.push(msg);
        console.error(`[OBS] ${msg}`);
      }
    }
  } catch (err: any) {
    const msg = `OBS list failed: ${err?.message ?? err}`;
    errors.push(msg);
    console.error(`[OBS] ${msg}`);
  }

  const result: SyncResult = { imported, skipped, errors, lastSync: new Date().toISOString() };
  lastSyncResult = result;
  return result;
}

export function getLastSyncResult(): SyncResult {
  return lastSyncResult;
}

export function startObsPolling(intervalMs = 30_000): void {
  console.log(`[OBS] Polling every ${intervalMs / 1000}s — folder: ${OBS_FOLDER_PREFIX}`);
  syncFromObs().then(r =>
    console.log(`[OBS] Initial sync — imported: ${r.imported}, skipped: ${r.skipped}, errors: ${r.errors.length}`)
  );
  setInterval(() => {
    syncFromObs().then(r => {
      if (r.imported > 0 || r.errors.length > 0) {
        console.log(`[OBS] Poll — imported: ${r.imported}, errors: ${r.errors.length}`);
      }
    });
  }, intervalMs);
}
