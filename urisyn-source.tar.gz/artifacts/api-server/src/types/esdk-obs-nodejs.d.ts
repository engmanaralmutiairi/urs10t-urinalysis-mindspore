declare module "esdk-obs-nodejs" {
  interface ObsConfig {
    access_key_id?: string;
    secret_access_key?: string;
    server: string;
  }

  interface CommonMsg {
    Status: number;
    Message: string;
  }

  interface ListObjectsResult {
    CommonMsg: CommonMsg;
    InterfaceResult?: { Contents?: Array<{ Key: string }> };
  }

  interface GetObjectResult {
    CommonMsg: CommonMsg;
    InterfaceResult?: { Content: string | Buffer };
  }

  class ObsClient {
    constructor(config: ObsConfig);
    listObjects(
      params: { Bucket: string },
      callback: (err: Error | null, result: ListObjectsResult) => void
    ): void;
    getObject(
      params: { Bucket: string; Key: string },
      callback: (err: Error | null, result: GetObjectResult) => void
    ): void;
  }

  export = ObsClient;
}
