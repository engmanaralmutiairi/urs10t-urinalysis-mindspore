import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Home, FlaskConical, Clock } from "lucide-react";
import logoUrl from "@assets/PHOTO-2026-03-10-20-34-52_1773427754048.jpg";

const tabs = [
  { href: "/",        label: "Home",    icon: Home },
  { href: "/results", label: "Results", icon: FlaskConical },
  { href: "/history", label: "History", icon: Clock },
];

export function MobileShell({ children, title, subtitle, headerExtra }: {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  headerExtra?: ReactNode;
}) {
  const [location] = useLocation();

  return (
    <div className="flex flex-col h-full">

      {/* ── Header ── */}
      <header className="shrink-0 relative"
        style={{ background: "linear-gradient(155deg, #174f6b 0%, #1f7287 50%, #2a9aa4 100%)" }}>

        {/* Soft decorative circle */}
        <div className="absolute -top-16 -right-16 w-56 h-56 rounded-full pointer-events-none"
          style={{ background: "radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 65%)" }} />

        <div className="relative px-5 pt-11 pb-6">
          {/* Top bar */}
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-2xl overflow-hidden"
                style={{ boxShadow: "0 2px 8px rgba(0,0,0,0.25)", border: "1.5px solid rgba(255,255,255,0.25)" }}>
                <img src={logoUrl} alt="URISYN" className="w-full h-full object-cover" />
              </div>
              <span className="text-white font-semibold text-[14px] tracking-widest uppercase opacity-90">
                URISYN
              </span>
            </div>

            {/* AI Live pill */}
            <div className="flex items-center gap-1.5 rounded-full px-3 py-1.5"
              style={{ background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.2)" }}>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse" />
              <span className="text-[10px] text-white/80 font-semibold uppercase tracking-widest">AI Live</span>
            </div>
          </div>

          {title && (
            <div>
              <p className="text-white/55 text-[12px] font-medium tracking-wide mb-0.5">{subtitle}</p>
              <h1 className="text-[24px] font-bold text-white leading-tight">{title}</h1>
            </div>
          )}
          {headerExtra && <div className="mt-4">{headerExtra}</div>}
        </div>

        {/* Bottom curve */}
        <div className="absolute bottom-0 left-0 right-0 h-5 rounded-t-[20px]"
          style={{ background: "hsl(210 28% 96%)" }} />
      </header>

      {/* ── Scrollable content ── */}
      <main className="flex-1 overflow-y-auto pb-28 bg-background">
        {children}
      </main>

      {/* ── Bottom nav ── */}
      <nav className="bottom-nav fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] z-50">
        <div className="flex items-center px-4 pt-1 pb-2">
          {tabs.map(({ href, label, icon: Icon }) => {
            const active = href === "/" ? location === "/" : location.startsWith(href);
            return (
              <Link key={href} href={href}
                className="relative flex-1 flex flex-col items-center gap-0.5 py-2 rounded-2xl transition-all duration-200"
              >
                {active && (
                  <span className="absolute inset-0 rounded-2xl"
                    style={{ background: "rgba(29,115,140,0.09)" }} />
                )}
                <div className="relative flex flex-col items-center gap-0.5">
                  <Icon
                    className="w-[20px] h-[20px] transition-all duration-200"
                    strokeWidth={active ? 2.2 : 1.6}
                    style={{ color: active ? "#1d738c" : "#b0bece" }}
                  />
                  <span className="text-[10px] font-semibold tracking-wide"
                    style={{ color: active ? "#1d738c" : "#c0cedb" }}>
                    {label}
                  </span>
                  {active && (
                    <span className="w-4 h-0.5 rounded-full mt-0.5"
                      style={{ background: "#1d738c" }} />
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
