import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Activity, ClipboardList, LayoutDashboard, Users, HeartPulse, ChevronRight } from "lucide-react";
import logoUrl from "@assets/PHOTO-2026-03-10-20-34-52_1773427754048.jpg";
import { cn } from "@/lib/utils";

export function Layout({ children, patientId }: { children: ReactNode; patientId?: string }) {
  const [location] = useLocation();

  const navItems = patientId ? [
    { name: "Dashboard", href: `/patients/${patientId}`, icon: LayoutDashboard },
    { name: "Test Results", href: `/patients/${patientId}/tests`, icon: ClipboardList },
    { name: "History & Trends", href: `/patients/${patientId}/history`, icon: Activity },
  ] : [];

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar — teal brand color */}
      <aside className="w-64 flex flex-col z-20 sidebar-bg shadow-xl">
        {/* Logo */}
        <div className="p-6 pb-4 border-b border-white/10">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl overflow-hidden border-2 border-white/30 shadow-lg">
              <img src={logoUrl} alt="URISYN Logo" className="w-full h-full object-cover" />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-xl tracking-tight text-white">
                URISYN
              </span>
              <span className="text-[10px] text-white/60 font-medium uppercase tracking-widest">
                Medical Portal
              </span>
            </div>
          </Link>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <p className="px-3 pb-2 text-[10px] font-semibold text-white/40 uppercase tracking-widest">
            Navigation
          </p>
          <Link href="/" className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200",
            location === "/"
              ? "bg-white/20 text-white shadow-sm"
              : "text-white/70 hover:bg-white/10 hover:text-white"
          )}>
            <Users className="w-4 h-4" />
            All Patients
          </Link>

          {patientId && (
            <div className="pt-4 space-y-1">
              <p className="px-3 pb-2 text-[10px] font-semibold text-white/40 uppercase tracking-widest flex items-center justify-between">
                <span>Patient View</span>
                <span className="bg-white/10 text-white/70 text-[9px] px-1.5 py-0.5 rounded">
                  #{patientId}
                </span>
              </p>
              {navItems.map((item) => {
                const isActive = item.name === "Dashboard"
                  ? location === item.href
                  : location.startsWith(item.href);
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200",
                      isActive
                        ? "bg-white/20 text-white shadow-sm"
                        : "text-white/70 hover:bg-white/10 hover:text-white"
                    )}
                  >
                    <item.icon className="w-4 h-4" />
                    {item.name}
                    {isActive && <ChevronRight className="w-3 h-3 ml-auto opacity-60" />}
                  </Link>
                );
              })}
            </div>
          )}
        </nav>

        {/* Disclaimer */}
        <div className="p-4 border-t border-white/10">
          <div className="bg-white/10 rounded-xl p-3 flex gap-2 items-start">
            <HeartPulse className="w-4 h-4 text-white/60 mt-0.5 shrink-0" />
            <p className="text-[10px] text-white/60 leading-tight">
              <strong className="text-white/80 block mb-0.5">⚠ Screening Only</strong>
              Not a medical diagnosis. Consult a healthcare professional.
            </p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto clinical-gradient">
        <div className="p-6 md:p-8 lg:p-10 max-w-7xl mx-auto min-h-full flex flex-col">
          {children}
        </div>
      </main>
    </div>
  );
}
