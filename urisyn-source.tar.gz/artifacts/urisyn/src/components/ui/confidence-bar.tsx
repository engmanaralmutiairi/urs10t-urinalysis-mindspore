import { motion } from "framer-motion";
import { cn, formatHealthStatus } from "@/lib/utils";

interface ConfidenceBarProps {
  percent: number;
  status: string;
  className?: string;
}

export function ConfidenceBar({ percent, status, className }: ConfidenceBarProps) {
  const formattedStatus = formatHealthStatus(status);
  
  const colors = {
    OK: "bg-success shadow-[0_0_10px_hsl(var(--success)/0.5)]",
    MILD: "bg-warning shadow-[0_0_10px_hsl(var(--warning)/0.5)]",
    CRITICAL: "bg-destructive shadow-[0_0_10px_hsl(var(--destructive)/0.5)]",
    UNKNOWN: "bg-muted",
  };

  return (
    <div className={cn("flex items-center gap-3 w-full", className)}>
      <div className="h-2 flex-1 bg-secondary rounded-full overflow-hidden relative">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percent}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className={cn("h-full rounded-full", colors[formattedStatus])}
        />
      </div>
      <span className={cn(
        "text-xs font-mono font-medium min-w-[3ch] text-right",
        formattedStatus === 'CRITICAL' ? 'text-destructive' : 'text-muted-foreground'
      )}>
        {percent}%
      </span>
    </div>
  );
}
