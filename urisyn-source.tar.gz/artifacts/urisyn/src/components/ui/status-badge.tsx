import { cn, formatHealthStatus } from "@/lib/utils";
import { AlertCircle, CheckCircle2, AlertTriangle } from "lucide-react";

interface StatusBadgeProps {
  status: string | null | undefined;
  className?: string;
  size?: "sm" | "md" | "lg";
  showIcon?: boolean;
}

export function StatusBadge({ status, className, size = "md", showIcon = true }: StatusBadgeProps) {
  const formattedStatus = formatHealthStatus(status);
  
  const sizes = {
    sm: "px-2.5 py-0.5 text-[10px]",
    md: "px-3 py-1 text-xs",
    lg: "px-4 py-1.5 text-sm",
  };

  const iconSizes = {
    sm: "w-3 h-3",
    md: "w-3.5 h-3.5",
    lg: "w-4 h-4",
  };

  const variants = {
    OK: "bg-success/10 text-success border-success/20",
    MILD: "bg-warning/10 text-warning border-warning/20",
    CRITICAL: "bg-destructive/10 text-destructive border-destructive/20 animate-pulse-slow",
    UNKNOWN: "bg-muted/50 text-muted-foreground border-border",
  };

  const icons = {
    OK: <CheckCircle2 className={iconSizes[size]} />,
    MILD: <AlertTriangle className={iconSizes[size]} />,
    CRITICAL: <AlertCircle className={iconSizes[size]} />,
    UNKNOWN: null,
  };

  return (
    <div className={cn(
      "inline-flex items-center gap-1.5 rounded-full font-semibold border uppercase tracking-wider",
      sizes[size],
      variants[formattedStatus],
      className
    )}>
      {showIcon && icons[formattedStatus]}
      {formattedStatus}
    </div>
  );
}
