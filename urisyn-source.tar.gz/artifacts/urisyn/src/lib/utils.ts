import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatHealthStatus(status: string | null | undefined): "OK" | "MILD" | "CRITICAL" | "UNKNOWN" {
  if (!status) return "UNKNOWN";
  const s = status.toLowerCase();
  if (s === "ok") return "OK";
  if (s === "mild") return "MILD";
  if (s === "critical") return "CRITICAL";
  return "UNKNOWN";
}
