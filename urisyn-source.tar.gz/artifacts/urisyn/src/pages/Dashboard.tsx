import { Link, useParams } from "wouter";
import { motion } from "framer-motion";
import { Activity, AlertCircle, ArrowRight, Calendar, Droplets, FileText, Plus } from "lucide-react";
import { useGetPatient, useGetPatientTests, useCreateTest } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { format } from "date-fns";

export default function Dashboard() {
  const params = useParams();
  const patientId = parseInt(params.id || "0");
  
  const { data: patient, isLoading: patientLoading } = useGetPatient(patientId);
  const { data: tests, isLoading: testsLoading, refetch: refetchTests } = useGetPatientTests(patientId);
  const createTest = useCreateTest();

  const handleCreateDemoTest = () => {
    createTest.mutate({
      data: {
        patientId,
        testDate: new Date().toISOString(),
        overallStatus: "critical",
        recommendation: "VISIT DOCTOR TODAY. High WBC and Trace Protein detected indicating possible infection.",
        notes: "Routine screening via app.",
        parameters: [
          { pad: "Leukocytes", result: "Large", confidencePercent: 99, status: "critical", explanation: "High WBC – possible UTI or kidney infection" },
          { pad: "Nitrite", result: "Negative", confidencePercent: 100, status: "ok", explanation: "Normal" },
          { pad: "Urobilinogen", result: "Normal", confidencePercent: 100, status: "ok", explanation: "Normal" },
          { pad: "Protein", result: "Trace", confidencePercent: 54, status: "mild", explanation: "Slightly elevated protein" },
          { pad: "pH", result: "8.0", confidencePercent: 100, status: "mild", explanation: "Slightly alkaline" },
          { pad: "Blood", result: "Hem Trace", confidencePercent: 100, status: "critical", explanation: "Trace blood detected" },
          { pad: "Specific Gravity", result: "1.015", confidencePercent: 100, status: "ok", explanation: "Normal hydration" },
          { pad: "Ketone", result: "Negative", confidencePercent: 100, status: "ok", explanation: "Normal" },
          { pad: "Bilirubin", result: "Negative", confidencePercent: 100, status: "ok", explanation: "Normal" },
          { pad: "Glucose", result: "Negative", confidencePercent: 100, status: "ok", explanation: "Normal" },
        ]
      }
    }, {
      onSuccess: () => refetchTests()
    });
  };

  if (patientLoading) {
    return (
      <Layout patientId={params.id}>
        <div className="flex items-center justify-center h-full">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      </Layout>
    );
  }

  if (!patient) return null;

  const latestTest = tests && tests.length > 0 ? tests[0] : null;

  return (
    <Layout patientId={params.id}>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground font-display">Medical Profile</h1>
        <p className="text-muted-foreground mt-1">Overview and recent activity for {patient.name}.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="lg:col-span-1 space-y-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-panel rounded-3xl p-1 relative overflow-hidden"
          >
            <div className="absolute top-0 inset-x-0 h-32 bg-gradient-to-b from-primary/20 to-transparent" />
            <div className="relative bg-card/50 rounded-[1.25rem] p-6 z-10">
              <div className="flex justify-between items-start mb-6">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-secondary to-background border border-primary/20 flex items-center justify-center text-3xl font-bold text-primary shadow-xl">
                  {patient.name.charAt(0)}
                </div>
                <StatusBadge status={patient.overallStatus || "UNKNOWN"} size="lg" />
              </div>
              
              <h2 className="text-2xl font-bold text-foreground">{patient.name}</h2>
              <p className="text-muted-foreground font-mono text-sm mb-6">{patient.medicalId}</p>
              
              <div className="space-y-4">
                <div className="bg-background/50 rounded-xl p-4 border border-border/50">
                  <p className="text-xs text-muted-foreground mb-1">Date of Birth</p>
                  <p className="font-medium">{format(new Date(patient.dateOfBirth), "MMMM d, yyyy")}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-background/50 rounded-xl p-4 border border-border/50">
                    <p className="text-xs text-muted-foreground mb-1">Gender</p>
                    <p className="font-medium">{patient.gender}</p>
                  </div>
                  <div className="bg-background/50 rounded-xl p-4 border border-border/50">
                    <p className="text-xs text-muted-foreground mb-1">Total Tests</p>
                    <p className="font-medium">{tests?.length || 0}</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Quick Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-2 gap-4"
          >
            <div className="glass-panel p-5 rounded-2xl">
              <Activity className="w-6 h-6 text-primary mb-3" />
              <p className="text-2xl font-bold text-foreground">{tests?.filter(t => t.overallStatus === 'critical').length || 0}</p>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Critical Alerts</p>
            </div>
            <div className="glass-panel p-5 rounded-2xl">
              <Droplets className="w-6 h-6 text-primary mb-3" />
              <p className="text-2xl font-bold text-foreground">{tests?.length || 0}</p>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Completed Scans</p>
            </div>
          </motion.div>
        </div>

        {/* Recent Activity */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-display font-semibold">Latest Test Result</h3>
            <Button variant="outline" size="sm" onClick={handleCreateDemoTest} disabled={createTest.isPending}>
              <Plus className="w-4 h-4 mr-2" />
              Simulate Scan
            </Button>
          </div>

          {testsLoading ? (
            <div className="glass-panel h-64 rounded-3xl animate-pulse" />
          ) : latestTest ? (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-panel rounded-3xl overflow-hidden border-2 border-primary/20"
            >
              {latestTest.overallStatus === "critical" && (
                <div className="bg-destructive text-destructive-foreground px-6 py-4 flex items-center gap-4">
                  <AlertCircle className="w-6 h-6 animate-pulse" />
                  <div>
                    <h4 className="font-bold text-lg tracking-tight">VISIT DOCTOR TODAY</h4>
                    <p className="text-sm opacity-90">{latestTest.recommendation}</p>
                  </div>
                </div>
              )}
              
              <div className="p-6 md:p-8">
                <div className="flex justify-between items-start mb-8 pb-6 border-b border-border/50">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <FileText className="w-5 h-5 text-primary" />
                      <h3 className="text-xl font-bold text-foreground">URS-10T Analysis</h3>
                    </div>
                    <p className="text-muted-foreground flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {format(new Date(latestTest.testDate), "MMMM d, yyyy 'at' h:mm a")}
                    </p>
                  </div>
                  <StatusBadge status={latestTest.overallStatus} size="lg" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  {latestTest.parameters.filter(p => p.status !== "ok").map((param, idx) => (
                    <div key={idx} className="bg-secondary/30 rounded-2xl p-5 border border-border/50">
                      <div className="flex justify-between mb-3">
                        <span className="font-bold text-foreground">{param.pad}</span>
                        <StatusBadge status={param.status} size="sm" />
                      </div>
                      <div className="flex items-end justify-between mb-3">
                        <span className="text-3xl font-display font-light text-foreground">{param.result}</span>
                        <span className="text-xs font-mono text-muted-foreground mb-1">{param.confidencePercent}% Conf.</span>
                      </div>
                      <p className="text-sm text-muted-foreground border-t border-border/50 pt-3 mt-2">
                        {param.explanation}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end">
                  <Link href={`/patients/${patient.id}/tests`}>
                    <Button variant="ghost-primary" className="gap-2">
                      View Full Detailed Report <ArrowRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="glass-panel rounded-3xl p-12 text-center border-dashed">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">No tests recorded</h3>
              <p className="text-muted-foreground mb-6">Simulate a scan to generate AI-powered urinalysis results.</p>
              <Button onClick={handleCreateDemoTest} disabled={createTest.isPending}>
                Simulate Scan
              </Button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
