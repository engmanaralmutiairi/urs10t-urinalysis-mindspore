import { useState } from "react";
import { useParams } from "wouter";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Calendar, TrendingUp } from "lucide-react";
import { useGetPatientTests } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { StatusBadge } from "@/components/ui/status-badge";
import { format } from "date-fns";

export default function History() {
  const params = useParams();
  const patientId = parseInt(params.id || "0");
  const { data: tests, isLoading } = useGetPatientTests(patientId);
  const [selectedPad, setSelectedPad] = useState("Leukocytes");

  if (isLoading) {
    return (
      <Layout patientId={params.id}>
        <div className="flex items-center justify-center h-full">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      </Layout>
    );
  }

  if (!tests || tests.length === 0) {
    return (
      <Layout patientId={params.id}>
        <div className="text-center py-20">No history available.</div>
      </Layout>
    );
  }

  // Reverse to get chronological order for charts
  const chronTests = [...tests].reverse();

  // Mapping string results to rough numbers for trend visualization
  const severityMap: Record<string, number> = {
    "Negative": 0,
    "Normal": 0,
    "Trace": 1,
    "Hem Trace": 1,
    "Small": 2,
    "Moderate": 3,
    "Large": 4,
  };

  const chartData = chronTests.map(test => {
    const p = test.parameters.find(p => p.pad === selectedPad);
    const rawVal = p?.result || "0";
    
    // Attempt numeric parse (for pH, Spec Grav) or map textual severity
    let numVal = parseFloat(rawVal);
    if (isNaN(numVal)) {
      numVal = severityMap[rawVal] !== undefined ? severityMap[rawVal] : 0;
    }

    return {
      date: format(new Date(test.testDate), "MMM d"),
      fullDate: format(new Date(test.testDate), "PPpp"),
      value: numVal,
      rawValue: rawVal,
      status: p?.status || "ok"
    };
  });

  const availablePads = tests[0]?.parameters.map(p => p.pad) || [];

  return (
    <Layout patientId={params.id}>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground font-display">Historical Trends</h1>
        <p className="text-muted-foreground mt-1">Track biomarker changes over time.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Chart Area */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass-panel rounded-3xl p-6 md:p-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold">Biomarker Trend</h3>
                  <p className="text-sm text-muted-foreground">Select a pad to view its history</p>
                </div>
              </div>
              
              <select 
                value={selectedPad}
                onChange={(e) => setSelectedPad(e.target.value)}
                className="bg-secondary border border-border text-foreground text-sm rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-primary/50 cursor-pointer min-w-[200px]"
              >
                {availablePads.map(pad => (
                  <option key={pad} value={pad}>{pad}</option>
                ))}
              </select>
            </div>

            <div className="h-[400px] w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 20, right: 20, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false}
                    dy={10}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="glass-panel p-4 rounded-xl border border-border shadow-xl">
                            <p className="text-xs text-muted-foreground mb-1">{data.fullDate}</p>
                            <p className="font-bold text-lg text-foreground flex items-center gap-2">
                              {data.rawValue}
                              <StatusBadge status={data.status} size="sm" showIcon={false} />
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={4}
                    dot={{ fill: 'hsl(var(--background))', stroke: 'hsl(var(--primary))', strokeWidth: 3, r: 6 }}
                    activeDot={{ r: 8, strokeWidth: 0, fill: 'hsl(var(--primary))' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="lg:col-span-1">
          <div className="glass-panel rounded-3xl p-6 h-full">
            <h3 className="text-xl font-display font-bold mb-6 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Test Timeline
            </h3>
            
            <div className="space-y-6 relative before:absolute before:inset-0 before:ml-[15px] before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-border before:via-border/50 before:to-transparent">
              {tests.map((test, i) => (
                <div key={test.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  {/* Timeline dot */}
                  <div className="flex items-center justify-center w-8 h-8 rounded-full border-4 border-background bg-secondary shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10 transition-colors group-hover:bg-primary">
                    <div className="w-2 h-2 rounded-full bg-muted-foreground group-hover:bg-primary-foreground" />
                  </div>
                  
                  {/* Card */}
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] glass-panel p-4 rounded-2xl hover:border-primary/50 transition-colors cursor-pointer relative">
                    <div className="flex flex-col gap-1 mb-2">
                      <span className="text-sm font-bold text-foreground">
                        {format(new Date(test.testDate), "MMM d, yyyy")}
                      </span>
                      <span className="text-xs text-muted-foreground font-mono">
                        {format(new Date(test.testDate), "HH:mm")}
                      </span>
                    </div>
                    <StatusBadge status={test.overallStatus} size="sm" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
