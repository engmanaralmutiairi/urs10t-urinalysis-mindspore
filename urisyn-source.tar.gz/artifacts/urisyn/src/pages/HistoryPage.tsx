import { useState } from "react";
import { motion } from "framer-motion";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import { AlertCircle, AlertTriangle, CheckCircle2, ChevronRight, Droplets } from "lucide-react";
import { Link } from "wouter";
import { useGetPatientTests } from "@workspace/api-client-react";
import { MobileShell } from "@/components/MobileShell";
import { format } from "date-fns";

const PATIENT_ID = 1;

const severityMap: Record<string, number> = {
  "Negative": 0, "Normal": 0, "Trace": 1, "Hem Trace": 1,
  "Small": 2, "Moderate": 3, "Large": 4,
};

const statusCfg = {
  critical: {
    color: "#B03040", bg: "#FFF4F5", border: "#F5C6CB", text: "Critical", dotColor: "#D95060",
    chipBg: "#FFF0F1", chipText: "#B03040",
  },
  mild: {
    color: "#9A5B0A", bg: "#FFF9F0", border: "#F5DDB0", text: "Mild", dotColor: "#D4882A",
    chipBg: "#FFF6E8", chipText: "#9A5B0A",
  },
  ok: {
    color: "#1A6E5E", bg: "#F2FBF9", border: "#A8DDD6", text: "OK", dotColor: "#2A9A88",
    chipBg: "#EEF8F5", chipText: "#1A6E5E",
  },
};

function StatusIcon({ status }: { status: string }) {
  if (status === "critical") return <AlertCircle className="w-4 h-4" style={{ color: "#B03040" }} />;
  if (status === "mild")     return <AlertTriangle className="w-4 h-4" style={{ color: "#9A5B0A" }} />;
  return <CheckCircle2 className="w-4 h-4" style={{ color: "#1A6E5E" }} />;
}

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  const cfg = statusCfg[d.status as keyof typeof statusCfg] ?? statusCfg.ok;
  return (
    <div className="rounded-2xl px-3 py-2.5 text-xs shadow-lg"
      style={{ background: "#fff", border: "1.5px solid #DDE5EE" }}>
      <p className="font-bold text-foreground text-[13px]">{d.rawValue}</p>
      <p className="text-muted-foreground mt-0.5">{d.date}</p>
      <div className="flex items-center gap-1.5 mt-1.5">
        <span className="w-2 h-2 rounded-full" style={{ background: cfg.dotColor }} />
        <span className="font-semibold" style={{ color: cfg.color }}>{cfg.text}</span>
      </div>
    </div>
  );
};

export default function HistoryPage() {
  const { data: tests, isLoading } = useGetPatientTests(PATIENT_ID);
  const [selectedPad, setSelectedPad] = useState("Leukocytes");

  const chronTests    = tests ? [...tests].reverse() : [];
  const availablePads = tests?.find(t => t.parameters?.length > 0)?.parameters.map(p => p.pad) ?? [];

  const chartData = chronTests.map(test => {
    const p   = test.parameters?.find(p => p.pad === selectedPad);
    const raw = p?.result ?? "0";
    let val   = parseFloat(raw);
    if (isNaN(val)) val = severityMap[raw] ?? 0;
    return {
      date: format(new Date(test.testDate), "d MMM"),
      value: val,
      rawValue: raw,
      status: p?.status ?? "ok",
    };
  });

  return (
    <MobileShell title="History" subtitle="Biomarker trends over time">
      <div className="px-4 pt-3 pb-6 space-y-4">

        {isLoading && (
          <div className="flex justify-center py-20">
            <div className="w-10 h-10 rounded-full border-[3px] border-t-transparent animate-spin"
              style={{ borderColor: "#C0DDED", borderTopColor: "transparent" }} />
          </div>
        )}

        {!isLoading && tests && tests.length > 0 && (
          <>
            {/* Trend chart */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="card p-4"
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Trend</p>
                  <p className="font-bold text-[15px] text-foreground mt-0.5">{selectedPad}</p>
                </div>
                <select
                  value={selectedPad}
                  onChange={e => setSelectedPad(e.target.value)}
                  className="text-[12px] rounded-xl px-3 py-2 outline-none font-semibold text-foreground cursor-pointer"
                  style={{ background: "#EEF3F8", border: "1px solid #DDE5EE" }}
                >
                  {availablePads.map(pad => (
                    <option key={pad} value={pad}>{pad}</option>
                  ))}
                </select>
              </div>

              <div className="h-44 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 8, right: 4, left: -32, bottom: 0 }}>
                    <defs>
                      <linearGradient id="clinicalGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%"   stopColor="#2A9A88" stopOpacity={0.18} />
                        <stop offset="100%" stopColor="#2A9A88" stopOpacity={0.01} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EEF2F8" vertical={false} />
                    <XAxis
                      dataKey="date"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                      dy={6}
                      tick={{ fill: "#9AAFBF", fontFamily: "DM Sans" }}
                    />
                    <YAxis
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                      tick={{ fill: "#9AAFBF", fontFamily: "DM Sans" }}
                    />
                    <Tooltip content={<CustomTooltip />} cursor={{ stroke: "#DDE5EE", strokeWidth: 1.5 }} />
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="#2A9A88"
                      strokeWidth={2}
                      fill="url(#clinicalGrad)"
                      dot={{ fill: "#fff", stroke: "#2A9A88", strokeWidth: 2, r: 4 }}
                      activeDot={{ r: 6, strokeWidth: 0, fill: "#1A6E5E" }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            {/* All scans */}
            <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground px-1">
              All Scans
            </p>

            <div className="space-y-2">
              {tests.map((test, i) => {
                const cfg          = statusCfg[test.overallStatus as keyof typeof statusCfg] ?? statusCfg.ok;
                const abnormalCount = test.parameters?.filter(p => p.status !== "ok").length ?? 0;
                const hasData       = (test.parameters?.length ?? 0) > 0;

                const card = (
                  <motion.div
                    key={test.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                    className="rounded-3xl px-4 py-3.5 flex items-center gap-3.5 transition-all"
                    style={{
                      background: hasData ? cfg.bg : "#F8FAFC",
                      border: `1.5px solid ${hasData ? cfg.border : "#DDE5EE"}`,
                      boxShadow: "0 1px 4px rgba(0,0,0,0.04)",
                      cursor: hasData ? "pointer" : "default",
                    }}
                  >
                    {/* Icon */}
                    <div className="w-9 h-9 rounded-2xl flex items-center justify-center shrink-0"
                      style={{ background: "#fff", border: `1px solid ${hasData ? cfg.border : "#DDE5EE"}` }}>
                      {hasData
                        ? <StatusIcon status={test.overallStatus} />
                        : <Droplets className="w-4 h-4 text-muted-foreground opacity-40" />}
                    </div>

                    {/* Date + summary */}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-[13px] text-foreground">
                        {format(new Date(test.testDate), "d MMMM yyyy")}
                      </p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        {!hasData
                          ? "No parameters recorded"
                          : abnormalCount === 0
                          ? "All parameters normal"
                          : `${abnormalCount} abnormal parameter${abnormalCount !== 1 ? "s" : ""}`}
                      </p>
                    </div>

                    {/* Status chip + arrow */}
                    <div className="flex items-center gap-2 shrink-0">
                      {hasData && (
                        <span className="text-[10px] font-bold uppercase px-2.5 py-1.5 rounded-full tracking-wide"
                          style={{ background: cfg.chipBg, color: cfg.chipText, border: `1px solid ${cfg.border}` }}>
                          {cfg.text}
                        </span>
                      )}
                      <ChevronRight
                        className="w-4 h-4 transition-all"
                        style={{ color: hasData ? cfg.color : "#C0CEDB", opacity: hasData ? 0.6 : 0.3 }}
                      />
                    </div>
                  </motion.div>
                );

                return hasData
                  ? <Link key={test.id} href={`/results/${test.id}`}>{card}</Link>
                  : <div key={test.id}>{card}</div>;
              })}
            </div>
          </>
        )}

        {!isLoading && (!tests || tests.length === 0) && (
          <div className="flex flex-col items-center py-20 gap-3 text-muted-foreground">
            <Droplets className="w-10 h-10 opacity-25" />
            <p className="text-sm">No history yet.</p>
          </div>
        )}
      </div>
    </MobileShell>
  );
}
