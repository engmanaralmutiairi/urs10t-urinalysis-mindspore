import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  AlertTriangle, ChevronRight, User, Activity,
  CloudDownload, RefreshCw, CheckCircle2, AlertCircle,
  Calendar, Droplets,
} from "lucide-react";
import { useGetPatient, useGetPatientTests } from "@workspace/api-client-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MobileShell } from "@/components/MobileShell";
import { format, formatDistanceToNow } from "date-fns";

const PATIENT_ID = 1;
const API_BASE = "/api";

interface ObsStatus { imported: number; skipped: number; errors: string[]; lastSync: string; }

function useObsStatus() {
  return useQuery<ObsStatus>({
    queryKey: ["obs-status"],
    queryFn: () => fetch(`${API_BASE}/obs/status`).then(r => r.json()),
    refetchInterval: 30_000,
  });
}

/* ── Soft clinical colour system ── */
const statusCfg = {
  critical: {
    label: "Critical",
    textColor: "#B03040",
    ringColor: "#D95060",
    ringTrack: "#FADADD",
    heroBg: "#FFF4F5",
    heroBorder: "#F5C6CB",
    pillBg: "#FFF0F1",
    pillBorder: "#F5C0C5",
    pillText: "#B03040",
    alertBg: "#FFF6F6",
    alertBorder: "#F5C6CB",
  },
  mild: {
    label: "Moderate",
    textColor: "#9A5B0A",
    ringColor: "#D4882A",
    ringTrack: "#FDECD0",
    heroBg: "#FFF9F0",
    heroBorder: "#F5DDB0",
    pillBg: "#FFF6E8",
    pillBorder: "#F5D8A0",
    pillText: "#9A5B0A",
    alertBg: "#FFFBF2",
    alertBorder: "#F5DDB0",
  },
  ok: {
    label: "Healthy",
    textColor: "#1A6E5E",
    ringColor: "#2A9A88",
    ringTrack: "#C8EFEA",
    heroBg: "#F2FBF9",
    heroBorder: "#A8DDD6",
    pillBg: "#EEF8F5",
    pillBorder: "#A0D8CE",
    pillText: "#1A6E5E",
    alertBg: "#F0FBF8",
    alertBorder: "#A8DDD6",
  },
};

function HealthRing({ status, pct }: { status: string; pct: number }) {
  const cfg = statusCfg[status as keyof typeof statusCfg] ?? statusCfg.ok;
  const size = 100;
  const stroke = 8;
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={cfg.ringTrack} strokeWidth={stroke} />
        <motion.circle
          cx={size/2} cy={size/2} r={r}
          fill="none" stroke={cfg.ringColor} strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circ}
          initial={{ strokeDashoffset: circ }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.4, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-[22px] font-bold leading-none" style={{ color: cfg.textColor }}>{pct}</span>
        <span className="text-[9px] font-bold uppercase tracking-widest mt-0.5 opacity-50" style={{ color: cfg.textColor }}>score</span>
      </div>
    </div>
  );
}

export default function Home() {
  const queryClient = useQueryClient();
  const { data: patient, isLoading: pLoading } = useGetPatient(PATIENT_ID);
  const { data: tests, isLoading: tLoading, refetch: refetchTests } = useGetPatientTests(PATIENT_ID);
  const { data: obsStatus } = useObsStatus();

  const syncMutation = useMutation({
    mutationFn: () => fetch(`${API_BASE}/obs/sync`, { method: "POST" }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["obs-status"] });
      refetchTests();
    },
  });

  const loading = pLoading || tLoading;
  const latestTest = tests?.find(t => t.parameters && t.parameters.length > 0);
  const criticalParams = latestTest?.parameters.filter(p => p.status === "critical") ?? [];
  const mildParams     = latestTest?.parameters.filter(p => p.status === "mild") ?? [];
  const abnormal = [...criticalParams, ...mildParams];
  const cfg = statusCfg[(latestTest?.overallStatus ?? "ok") as keyof typeof statusCfg];
  const paramCount = latestTest?.parameters.length ?? 0;
  const healthScore = latestTest && paramCount > 0
    ? Math.round((latestTest.parameters.filter(p => p.status === "ok").length / paramCount) * 100)
    : 100;

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  return (
    <MobileShell title={loading ? "Loading…" : `${greeting}, ${patient?.name?.split(" ")[0] ?? "—"}`}>
      <div className="px-4 pt-3 pb-6 space-y-3">

        {/* ── Status Hero ── */}
        {latestTest && (
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-3xl overflow-hidden"
            style={{
              background: cfg.heroBg,
              border: `1.5px solid ${cfg.heroBorder}`,
              boxShadow: "0 2px 16px rgba(0,0,0,0.06)",
            }}
          >
            <div className="px-5 pt-5 pb-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <p className="text-[11px] font-bold uppercase tracking-widest opacity-50 mb-1"
                    style={{ color: cfg.textColor }}>
                    Overall Status
                  </p>
                  <h2 className="text-[28px] font-bold leading-none" style={{ color: cfg.textColor }}>
                    {cfg.label}
                  </h2>
                  <p className="text-[12px] text-muted-foreground flex items-center gap-1.5 mt-2">
                    <Calendar className="w-3 h-3" />
                    {format(new Date(latestTest.testDate), "d MMMM yyyy")}
                  </p>
                </div>
                <HealthRing status={latestTest.overallStatus} pct={healthScore} />
              </div>

              {latestTest.overallStatus === "critical" && (
                <motion.div
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="flex items-center gap-3 rounded-2xl px-4 py-3 mt-4"
                  style={{ background: cfg.alertBg, border: `1px solid ${cfg.alertBorder}` }}
                >
                  <AlertTriangle className="w-4 h-4 shrink-0" style={{ color: cfg.textColor }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] font-bold" style={{ color: cfg.textColor }}>Visit a Doctor Today</p>
                    <p className="text-[11px] opacity-70 mt-0.5" style={{ color: cfg.textColor }}>
                      Critical markers detected. Seek medical attention promptly.
                    </p>
                  </div>
                  <Link href="/results">
                    <ChevronRight className="w-4 h-4 opacity-50" style={{ color: cfg.textColor }} />
                  </Link>
                </motion.div>
              )}
            </div>

            {/* Stats strip */}
            <div className="grid grid-cols-3 divide-x border-t"
              style={{ borderColor: cfg.heroBorder, background: "rgba(255,255,255,0.55)" }}>
              {[
                { label: "Total Tests",  value: tests?.length ?? 0 },
                { label: "Abnormal",     value: abnormal.length },
                {
                  label: "AI Confidence",
                  value: paramCount > 0
                    ? `${Math.round(latestTest.parameters.reduce((a, p) => a + (p.confidencePercent ?? 0), 0) / paramCount)}%`
                    : "—",
                },
              ].map(({ label, value }) => (
                <div key={label} className="flex flex-col items-center py-3" style={{ borderColor: cfg.heroBorder }}>
                  <span className="text-[18px] font-bold text-foreground">{value}</span>
                  <span className="text-[10px] text-muted-foreground font-medium mt-0.5">{label}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* ── Patient profile card ── */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.06 }}
          className="card"
        >
          <div className="px-4 py-4 flex items-center gap-4">
            {/* Avatar */}
            <div className="w-12 h-12 rounded-full flex items-center justify-center text-[18px] font-bold text-white shrink-0"
              style={{ background: "linear-gradient(135deg, #1d738c, #2a9aa4)", boxShadow: "0 3px 12px rgba(29,115,140,0.3)" }}>
              {patient?.name?.charAt(0) ?? "?"}
            </div>

            <div className="flex-1 min-w-0">
              <p className="font-bold text-[15px] text-foreground">{patient?.name ?? "—"}</p>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-[11px] text-muted-foreground font-mono">{patient?.medicalId ?? "—"}</span>
                <span className="text-muted-foreground/30">·</span>
                <span className="text-[11px] text-muted-foreground">
                  {patient?.gender}
                </span>
              </div>
              {patient?.dateOfBirth && (
                <div className="flex items-center gap-1 mt-0.5">
                  <User className="w-2.5 h-2.5 text-muted-foreground" />
                  <span className="text-[11px] text-muted-foreground">
                    {format(new Date(patient.dateOfBirth), "dd MMM yyyy")}
                  </span>
                </div>
              )}
            </div>

            {latestTest && (
              <span className="text-[10px] font-bold uppercase px-2.5 py-1.5 rounded-full shrink-0 tracking-wide"
                style={{ background: cfg.pillBg, color: cfg.pillText, border: `1px solid ${cfg.pillBorder}` }}>
                {cfg.label}
              </span>
            )}
          </div>
        </motion.div>

        {/* ── Latest scan markers ── */}
        {latestTest && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card overflow-hidden"
          >
            <div className="flex items-center justify-between px-4 pt-4 pb-3 border-b border-border">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl flex items-center justify-center"
                  style={{ background: "#EEF6F8", border: "1px solid #C0DDED" }}>
                  <Activity className="w-3.5 h-3.5" style={{ color: "#1d738c" }} />
                </div>
                <div>
                  <p className="font-semibold text-[13px] text-foreground">Latest Scan — URS-10T</p>
                  <p className="text-[11px] text-muted-foreground">{format(new Date(latestTest.testDate), "d MMM yyyy")}</p>
                </div>
              </div>
            </div>

            <div className="divide-y divide-border">
              {abnormal.length === 0 && (
                <div className="px-4 py-4 flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 shrink-0" style={{ color: "#2A9A88" }} />
                  <p className="text-[13px] text-muted-foreground">All parameters within normal range</p>
                </div>
              )}

              {abnormal.map((p, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.12 + i * 0.04 }}
                  className="flex items-center gap-3 px-4 py-3"
                >
                  <div className="w-2 h-2 rounded-full shrink-0"
                    style={{ background: p.status === "critical" ? "#D95060" : "#D4882A" }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] font-semibold text-foreground">{p.pad}</p>
                    <p className="text-[11px] text-muted-foreground truncate">{p.explanation}</p>
                  </div>
                  <span className="text-[12px] font-bold shrink-0 font-mono"
                    style={{ color: p.status === "critical" ? "#B03040" : "#9A5B0A" }}>
                    {p.result}
                  </span>
                </motion.div>
              ))}
            </div>

            <Link href="/results"
              className="flex items-center justify-center gap-2 py-3.5 border-t border-border text-[13px] font-semibold transition-colors"
              style={{ color: "#1d738c" }}
            >
              View full report <ChevronRight className="w-4 h-4" />
            </Link>
          </motion.div>
        )}

        {/* ── Quick stats grid ── */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.14 }}
          className="grid grid-cols-3 gap-2.5"
        >
          {[
            { label: "Total Tests",  value: tests?.length ?? 0,                                                          accent: "#1d738c" },
            { label: "Critical",     value: tests?.filter(t => t.overallStatus === "critical").length ?? 0,              accent: "#B03040" },
            { label: "All Clear",    value: tests?.filter(t => t.overallStatus === "ok" && t.parameters?.length).length ?? 0, accent: "#1A6E5E" },
          ].map(({ label, value, accent }) => (
            <div key={label} className="card py-4 text-center">
              <p className="text-[22px] font-bold" style={{ color: accent }}>{value}</p>
              <p className="text-[10px] text-muted-foreground font-medium mt-0.5 leading-snug">{label}</p>
            </div>
          ))}
        </motion.div>

        {/* ── OBS Cloud sync ── */}
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.18 }}
          className="card px-4 py-4"
        >
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-2xl flex items-center justify-center shrink-0"
                style={{ background: "#EEF6F8", border: "1px solid #C0DDED" }}>
                <CloudDownload className="w-4 h-4" style={{ color: "#1d738c" }} />
              </div>
              <div>
                <p className="text-[13px] font-semibold text-foreground">Cloud Sync</p>
                <p className="text-[11px] text-muted-foreground">
                  {obsStatus?.lastSync === "Never" ? "Not yet synced"
                    : obsStatus?.lastSync ? formatDistanceToNow(new Date(obsStatus.lastSync), { addSuffix: true })
                    : "Connecting…"}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {obsStatus?.errors?.length
                ? <AlertCircle className="w-4 h-4 text-amber-500" />
                : obsStatus?.lastSync && obsStatus.lastSync !== "Never"
                ? <CheckCircle2 className="w-4 h-4" style={{ color: "#2A9A88" }} />
                : null}
              <button
                onClick={() => syncMutation.mutate()}
                disabled={syncMutation.isPending}
                className="flex items-center gap-1.5 text-[12px] font-semibold disabled:opacity-40 rounded-xl px-3 py-1.5"
                style={{ background: "#EEF6F8", border: "1px solid #C0DDED", color: "#1d738c" }}
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncMutation.isPending ? "animate-spin" : ""}`} />
                {syncMutation.isPending ? "Syncing…" : "Sync"}
              </button>
            </div>
          </div>
          {syncMutation.data && (
            <p className="text-[11px] text-muted-foreground mt-2.5 pl-12">
              {syncMutation.data.imported > 0
                ? `✓ ${syncMutation.data.imported} new result(s) imported`
                : "✓ Already up to date"}
            </p>
          )}
        </motion.div>

        {/* ── Disclaimer ── */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.22 }}
          className="rounded-2xl px-4 py-3 flex gap-2.5 items-start"
          style={{ background: "#F4F7FA", border: "1px solid #DDE5EE" }}
        >
          <Droplets className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-0.5" />
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            <span className="font-semibold text-foreground/60">Screening only.</span>{" "}
            AI-assisted results — not a medical diagnosis. Always consult a healthcare professional.
          </p>
        </motion.div>

      </div>
    </MobileShell>
  );
}
