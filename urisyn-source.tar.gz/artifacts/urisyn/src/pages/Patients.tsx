import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Plus, Search, UserPlus, Filter } from "lucide-react";
import { useGetPatients, useCreatePatient } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { format } from "date-fns";

export default function Patients() {
  const { data: patients, isLoading, refetch } = useGetPatients();
  const createPatient = useCreatePatient();
  const [search, setSearch] = useState("");

  const handleCreateDemo = () => {
    createPatient.mutate({
      data: {
        name: "Eleanor Vance",
        dateOfBirth: "1985-06-15",
        gender: "Female",
        email: "eleanor.v@example.com",
        medicalId: "MED-8842-19A",
      }
    }, {
      onSuccess: () => refetch()
    });
  };

  const filteredPatients = patients?.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.medicalId.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Layout>
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Patient Directory</h1>
          <p className="text-muted-foreground mt-1">Manage and monitor patient urinalysis records.</p>
        </div>
        <Button onClick={handleCreateDemo} disabled={createPatient.isPending} className="shrink-0">
          <UserPlus className="w-4 h-4" />
          Add Demo Patient
        </Button>
      </div>

      <div className="glass-panel rounded-2xl p-4 mb-6 flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input 
            type="text" 
            placeholder="Search patients by name or ID..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-background/50 border border-border rounded-xl pl-12 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all placeholder:text-muted-foreground"
          />
        </div>
        <Button variant="outline" className="shrink-0 gap-2">
          <Filter className="w-4 h-4" />
          Filter
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="glass-panel rounded-2xl h-48 animate-pulse bg-secondary/50" />
          ))}
        </div>
      ) : filteredPatients?.length === 0 ? (
        <div className="text-center py-20 glass-panel rounded-3xl">
          <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-display font-semibold mb-2">No patients found</h3>
          <p className="text-muted-foreground max-w-md mx-auto mb-6">
            Get started by adding a new patient to track their AI-powered urinalysis results.
          </p>
          <Button onClick={handleCreateDemo} disabled={createPatient.isPending}>
            Create Demo Patient
          </Button>
        </div>
      ) : (
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          initial="hidden"
          animate="show"
          variants={{
            hidden: { opacity: 0 },
            show: {
              opacity: 1,
              transition: { staggerChildren: 0.1 }
            }
          }}
        >
          {filteredPatients?.map((patient) => (
            <motion.div 
              key={patient.id}
              variants={{
                hidden: { opacity: 0, y: 20 },
                show: { opacity: 1, y: 0 }
              }}
            >
              <Link 
                href={`/patients/${patient.id}`}
                className="block group h-full"
              >
                <div className="glass-panel h-full rounded-2xl p-6 transition-all duration-300 hover:border-primary/50 hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)] hover:-translate-y-1 hover:shadow-primary/10">
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-secondary flex items-center justify-center border border-primary/20 text-primary font-display font-bold text-lg">
                      {patient.name.charAt(0)}
                    </div>
                    <StatusBadge status={patient.overallStatus || "UNKNOWN"} />
                  </div>
                  
                  <h3 className="text-lg font-bold text-foreground mb-1 group-hover:text-primary transition-colors">
                    {patient.name}
                  </h3>
                  
                  <div className="space-y-2 mt-4 text-sm text-muted-foreground">
                    <div className="flex justify-between items-center border-b border-border/50 pb-2">
                      <span>Medical ID</span>
                      <span className="font-mono text-foreground">{patient.medicalId}</span>
                    </div>
                    <div className="flex justify-between items-center border-b border-border/50 pb-2">
                      <span>Last Test</span>
                      <span className="text-foreground">
                        {patient.latestTestDate ? format(new Date(patient.latestTestDate), "MMM d, yyyy") : "No tests yet"}
                      </span>
                    </div>
                    <div className="flex justify-between items-center pt-1">
                      <span>DOB</span>
                      <span className="text-foreground">{format(new Date(patient.dateOfBirth), "MMM d, yyyy")}</span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      )}
    </Layout>
  );
}
