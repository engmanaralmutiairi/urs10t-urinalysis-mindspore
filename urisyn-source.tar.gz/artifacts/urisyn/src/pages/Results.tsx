import { motion } from "framer-motion";
import {
  AlertCircle, CheckCircle2, AlertTriangle, Droplets,
  TrendingUp, TrendingDown, Minus, CalendarDays, ArrowLeft,
} from "lucide-react";
import { Link, useParams } from "wouter";
import { useGetPatientTests } from "@workspace/api-client-react";
import { MobileShell } from "@/components/MobileShell";
import { format } from "date-fns";

const PATIENT_ID = 1;

/* ── Severity ordering ── */
const SEVERITY: Record<string, number> = {
  "Negative": 0, "Normal": 0,
  "Trace": 1, "Hem Trace": 1, "Non-hem Trace": 1,
  "Small": 2, "Mild": 2,
  "Moderate": 3,
  "Large": 4, "Positive": 4, "Very Large": 4, "Very High": 4, "High": 3,
  "Elevated": 2,
};

function severityOf(r: string) {
  const v = SEVERITY[r];
  if (v !== undefined) return v;
  const n = parseFloat(r);
  return isNaN(n) ? 0 : n;
}

type Trend = "worse" | "better" | "same" | "new";

function calcTrend(curr: string, prev?: string): Trend {
  if (!prev) return "new";
  const c = severityOf(curr), p = severityOf(prev);
  return c > p ? "worse" : c < p ? "better" : "same";
}

/* ── Design tokens per status ── */
const TOKEN = {
  critical: {
    accentBar:   "#D95060",
    cardBg:      "#FFFBFB",
    cardBorder:  "#EFD0D3",
    titleColor:  "#8B2830",
    resultColor: "#B03040",
    pillBg:      "#FFF0F1",
    pillBorder:  "#F5C0C5",
    pillText:    "#B03040",
    iconColor:   "#D95060",
    label:       "Critical",
    iconEl:      () => <AlertCircle size={13} color="#D95060" />,
  },
  mild: {
    accentBar:   "#D4882A",
    cardBg:      "#FFFDF8",
    cardBorder:  "#EDD9A8",
    titleColor:  "#7A4A08",
    resultColor: "#9A5B0A",
    pillBg:      "#FFF6E8",
    pillBorder:  "#F0D090",
    pillText:    "#9A5B0A",
    iconColor:   "#D4882A",
    label:       "Mild",
    iconEl:      () => <AlertTriangle size={13} color="#D4882A" />,
  },
  ok: {
    accentBar:   "#2A9A88",
    cardBg:      "#FAFFFE",
    cardBorder:  "#C8E8E3",
    titleColor:  "#1A5C50",
    resultColor: "#1A6E5E",
    pillBg:      "#EEF8F5",
    pillBorder:  "#A0D8CE",
    pillText:    "#1A6E5E",
    iconColor:   "#2A9A88",
    label:       "Normal",
    iconEl:      () => <CheckCircle2 size={13} color="#2A9A88" />,
  },
} as const;

function StatusPill({ status, size = "md" }: { status: string; size?: "sm" | "md" }) {
  const t = TOKEN[status as keyof typeof TOKEN] ?? TOKEN.ok;
  const px = size === "sm" ? "8px" : "10px";
  const py = size === "sm" ? "3px" : "5px";
  const fs = size === "sm" ? "9px" : "10px";
  return (
    <span
      className="inline-flex items-center gap-1 font-bold uppercase tracking-wider whitespace-nowrap rounded-full"
      style={{ background: t.pillBg, border: `1px solid ${t.pillBorder}`, color: t.pillText,
               padding: `${py} ${px}`, fontSize: fs }}>
      {t.iconEl()}{t.label}
    </span>
  );
}

function TrendChip({ trend, prevResult }: { trend: Trend; prevResult?: string }) {
  if (trend === "new" || !prevResult) return null;

  const map = {
    worse:  { bg: "#FFF0F1", color: "#B03040", border: "#F5C0C5", icon: <TrendingUp size={11} />,  text: `↑ ${prevResult}` },
    better: { bg: "#EEF8F5", color: "#1A6E5E", border: "#A0D8CE", icon: <TrendingDown size={11} />, text: `↓ ${prevResult}` },
    same:   { bg: "#F4F7FA", color: "#607080", border: "#D5E0EC", icon: <Minus size={11} />,        text: prevResult },
  }[trend];

  return (
    <span className="inline-flex items-center gap-1 rounded-lg text-[11px] font-semibold px-2 py-0.5 whitespace-nowrap"
      style={{ background: map.bg, color: map.color, border: `1px solid ${map.border}` }}>
      {map.icon}{map.text}
    </span>
  );
}

/* ── Biomarker card ── */
function ParamCard({
  p, prevParam, index,
}: {
  p: { pad: string; result: string; status: string; confidencePercent: number; explanation: string };
  prevParam?: { result: string; status: string };
  index: number;
}) {
  const t     = TOKEN[p.status as keyof typeof TOKEN] ?? TOKEN.ok;
  const trend = calcTrend(p.result, prevParam?.result);
  const pct   = Math.min(100, Math.max(0, p.confidencePercent ?? 0));

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="overflow-hidden"
      style={{
        background: t.cardBg,
        border:     `1px solid ${t.cardBorder}`,
        borderRadius: "18px",
        boxShadow: "0 1px 6px rgba(0,0,0,0.05)",
      }}
    >
      {/* Coloured left accent — 3 px, full height */}
      <div className="flex">
        <div className="w-[3px] shrink-0 rounded-l-[18px]"
          style={{ background: t.accentBar, alignSelf: "stretch" }} />

        <div className="flex-1 px-4 py-4">

          {/* ── Row 1: Name + Status pill ── */}
          <div className="flex items-start justify-between gap-2 mb-1">
            <div className="flex items-center gap-1.5 min-w-0">
              {t.iconEl()}
              <span className="font-semibold text-[14px] truncate" style={{ color: t.titleColor }}>
                {p.pad}
              </span>
            </div>
            <StatusPill status={p.status} size="sm" />
          </div>

          {/* ── Row 2: Explanation ── */}
          <p className="text-[11.5px] text-muted-foreground leading-snug pl-5 mb-4">
            {p.status !== "ok" ? p.explanation : "Within normal range"}
          </p>

          {/* ── Divider ── */}
          <div className="border-t border-dashed mb-3.5"
            style={{ borderColor: t.cardBorder }} />

          {/* ── Row 3: Result | Trend | Confidence ── */}
          <div className="flex items-center gap-3">
            {/* Result value — most prominent */}
            <div className="shrink-0">
              <p className="text-[10px] text-muted-foreground font-medium mb-0.5 uppercase tracking-wider">Result</p>
              <p className="text-[20px] font-bold leading-none" style={{ color: t.resultColor }}>
                {p.result}
              </p>
            </div>

            <div className="w-px self-stretch" style={{ background: t.cardBorder }} />

            {/* Trend vs previous */}
            <div className="shrink-0">
              <p className="text-[10px] text-muted-foreground font-medium mb-1 uppercase tracking-wider">vs Last</p>
              <TrendChip trend={trend} prevResult={prevParam?.result} />
              {trend === "new" && (
                <span className="text-[11px] text-muted-foreground">First test</span>
              )}
            </div>

            <div className="flex-1" />

            {/* Confidence */}
            <div className="text-right shrink-0">
              <p className="text-[10px] text-muted-foreground font-medium mb-0.5 uppercase tracking-wider">AI Conf.</p>
              <p className="text-[20px] font-bold leading-none" style={{ color: t.resultColor }}>
                {pct}<span className="text-[13px] font-semibold opacity-60">%</span>
              </p>
            </div>
          </div>

          {/* ── Confidence bar (thin, decorative) ── */}
          <div className="mt-3 h-1 rounded-full overflow-hidden" style={{ background: `${t.accentBar}20` }}>
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${pct}%` }}
              transition={{ duration: 1, ease: "easeOut", delay: index * 0.05 + 0.2 }}
              className="h-full rounded-full"
              style={{ background: t.accentBar }}
            />
          </div>

        </div>
      </div>
    </motion.div>
  );
}

/* ── Page ── */
export default function Results() {
  const params = useParams<{ testId?: string }>();
  const selectedId = params.testId ? Number(params.testId) : null;
  const fromHistory = selectedId !== null;

  const { data: tests, isLoading } = useGetPatientTests(PATIENT_ID);

  const testsWithParams = tests?.filter(t => t.parameters && t.parameters.length > 0) ?? [];

  /* If a testId is in the URL, show that test; otherwise show the latest */
  const test = selectedId
    ? testsWithParams.find(t => t.id === selectedId)
    : testsWithParams[0];

  /* Previous test = the one chronologically before the shown test */
  const testIndex = test ? testsWithParams.findIndex(t => t.id === test.id) : -1;
  const prevTest  = testIndex >= 0 ? testsWithParams[testIndex + 1] : undefined;
  const prevByPad = new Map(prevTest?.parameters.map(p => [p.pad, p]) ?? []);

  /* Summary counts */
  const criticalCount = test?.parameters.filter(p => p.status === "critical").length ?? 0;
  const mildCount     = test?.parameters.filter(p => p.status === "mild").length ?? 0;
  const okCount       = test?.parameters.filter(p => p.status === "ok").length ?? 0;

  return (
    <MobileShell title="Lab Report" subtitle="URS-10T Urinalysis">
      <div className="px-4 pt-3 pb-6 space-y-3">

        {/* Back to history button */}
        {fromHistory && (
          <Link href="/history">
            <div className="flex items-center gap-1.5 text-[13px] font-semibold mb-1 -mt-1"
              style={{ color: "#1d738c" }}>
              <ArrowLeft size={15} />
              Back to History
            </div>
          </Link>
        )}

        {/* Loading */}
        {isLoading && (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 rounded-full border-[2.5px] border-t-transparent animate-spin"
              style={{ borderColor: "#C0DDED", borderTopColor: "transparent" }} />
          </div>
        )}

        {/* Empty */}
        {!isLoading && !test && (
          <div className="flex flex-col items-center py-20 gap-3 text-muted-foreground">
            <Droplets className="w-10 h-10 opacity-25" />
            <p className="text-sm">No test data found.</p>
          </div>
        )}

        {test && (
          <>
            {/* ── Critical alert ── */}
            {test.overallStatus === "critical" && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-start gap-3 rounded-2xl px-4 py-3.5"
                style={{ background: "#FFF4F5", border: "1.5px solid #EFD0D3" }}
              >
                <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: "#FADADD" }}>
                  <AlertCircle size={16} color="#B03040" />
                </div>
                <div>
                  <p className="font-bold text-[14px]" style={{ color: "#8B2830" }}>Visit a Doctor Today</p>
                  <p className="text-[12px] leading-relaxed mt-0.5 opacity-80" style={{ color: "#8B2830" }}>
                    Critical markers detected. Not a diagnosis — please seek professional care promptly.
                  </p>
                </div>
              </motion.div>
            )}

            {/* ── Report header card ── */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.05 }}
              className="card px-5 py-4"
            >
              {/* Title row */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground mb-0.5">
                    Test Report
                  </p>
                  <p className="font-bold text-[16px] text-foreground">URS-10T Urinalysis</p>
                </div>
                <StatusPill status={test.overallStatus} />
              </div>

              {/* Date row */}
              <div className="flex items-center gap-1.5 text-[12px] text-muted-foreground mb-3">
                <CalendarDays size={13} />
                <span className="font-semibold text-foreground">
                  {format(new Date(test.testDate), "d MMMM yyyy")}
                </span>
                {prevTest && (
                  <>
                    <span className="text-muted-foreground/40 mx-1">·</span>
                    <span>vs {format(new Date(prevTest.testDate), "d MMM yyyy")}</span>
                    <StatusPill status={prevTest.overallStatus} size="sm" />
                  </>
                )}
              </div>

              {/* Summary counts */}
              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-border">
                {[
                  { n: criticalCount, label: "Critical", color: "#B03040", bg: "#FFF0F1", border: "#F5C0C5" },
                  { n: mildCount,     label: "Mild",     color: "#9A5B0A", bg: "#FFF6E8", border: "#F0D090" },
                  { n: okCount,       label: "Normal",   color: "#1A6E5E", bg: "#EEF8F5", border: "#A0D8CE" },
                ].map(({ n, label, color, bg, border }) => (
                  <div key={label} className="flex flex-col items-center py-2 rounded-xl"
                    style={{ background: bg, border: `1px solid ${border}` }}>
                    <span className="text-[20px] font-bold leading-none" style={{ color }}>{n}</span>
                    <span className="text-[10px] font-semibold mt-0.5 opacity-80" style={{ color }}>{label}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* ── Section label ── */}
            <div className="flex items-center gap-2 px-1 pt-1">
              <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
                Biomarker Detail
              </p>
              <div className="flex-1 h-px" style={{ background: "#DDE5EE" }} />
              <p className="text-[10px] text-muted-foreground">
                {test.parameters.length} markers
              </p>
            </div>

            {/* ── Sorted params: critical → mild → ok ── */}
            <div className="space-y-2.5">
              {[...test.parameters]
                .sort((a, b) => {
                  const order = { critical: 0, mild: 1, ok: 2 };
                  return (order[a.status as keyof typeof order] ?? 2) - (order[b.status as keyof typeof order] ?? 2);
                })
                .map((p, i) => (
                  <ParamCard
                    key={p.pad}
                    p={p}
                    prevParam={prevByPad.get(p.pad)}
                    index={i}
                  />
                ))}
            </div>

            {/* ── Disclaimer ── */}
            <p className="text-center text-[11px] text-muted-foreground px-2 pt-1 leading-relaxed">
              Screening result only — not a medical diagnosis.
              Always consult a qualified healthcare professional.
            </p>
          </>
        )}
      </div>
    </MobileShell>
  );
}
