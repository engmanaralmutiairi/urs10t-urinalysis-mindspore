import { useParams } from "wouter";
import { motion } from "framer-motion";
import { AlertCircle, Download, FileText } from "lucide-react";
import { useGetPatientTests } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { ConfidenceBar } from "@/components/ui/confidence-bar";
import { format } from "date-fns";

export default function TestResults() {
  const params = useParams();
  const patientId = parseInt(params.id || "0");
  
  const { data: tests, isLoading } = useGetPatientTests(patientId);

  if (isLoading) {
    return (
      <Layout patientId={params.id}>
        <div className="flex items-center justify-center h-full">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      </Layout>
    );
  }

  // Use the most recent test for this page, or we could support ?testId=x
  const test = tests && tests.length > 0 ? tests[0] : null;

  if (!test) {
    return (
      <Layout patientId={params.id}>
        <div className="text-center py-20">No tests available.</div>
      </Layout>
    );
  }

  return (
    <Layout patientId={params.id}>
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground font-display">Test Results</h1>
          <p className="text-muted-foreground mt-1">Detailed breakdown of URS-10T scan.</p>
        </div>
        <Button variant="outline" className="shrink-0 gap-2">
          <Download className="w-4 h-4" />
          Export PDF
        </Button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-panel rounded-[2rem] overflow-hidden"
      >
        {/* Banner */}
        {test.overallStatus === "critical" && (
          <div className="bg-destructive px-6 md:px-10 py-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-center gap-4 text-destructive-foreground">
              <div className="bg-white/20 p-3 rounded-full">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div>
                <h2 className="text-2xl font-bold tracking-tight mb-1">VISIT DOCTOR TODAY</h2>
                <p className="opacity-90 max-w-xl text-sm leading-relaxed">
                  Multiple critical biomarkers detected. This is a screening only and requires professional medical attention immediately.
                </p>
              </div>
            </div>
            <Button variant="secondary" className="bg-white text-destructive hover:bg-white/90 shrink-0">
              Find Clinic
            </Button>
          </div>
        )}

        {/* Header */}
        <div className="p-6 md:p-10 border-b border-border/50 flex flex-col md:flex-row md:items-center justify-between gap-6 bg-card/40">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-primary/10 text-primary rounded-xl flex items-center justify-center">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-foreground mb-1">Standard URS-10T</h3>
              <p className="text-muted-foreground text-sm font-mono">
                {format(new Date(test.testDate), "MMM d, yyyy - HH:mm:ss")}
              </p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Overall Assessment</span>
            <StatusBadge status={test.overallStatus} size="lg" />
          </div>
        </div>

        {/* Detailed Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-secondary/50 border-b border-border/50 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                <th className="p-6 font-medium">Biomarker / PAD</th>
                <th className="p-6 font-medium">Result Value</th>
                <th className="p-6 font-medium w-64">AI Confidence</th>
                <th className="p-6 font-medium">Status</th>
                <th className="p-6 font-medium">Explanation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {test.parameters.map((param, idx) => (
                <motion.tr 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  key={idx} 
                  className={`group transition-colors hover:bg-secondary/30 ${
                    param.status === 'critical' ? 'bg-destructive/5 hover:bg-destructive/10' : ''
                  }`}
                >
                  <td className="p-6">
                    <span className="font-bold text-foreground flex items-center gap-2">
                      {param.status === 'critical' && <AlertCircle className="w-4 h-4 text-destructive" />}
                      {param.pad}
                    </span>
                  </td>
                  <td className="p-6">
                    <span className="font-display text-lg text-foreground bg-background/50 px-3 py-1 rounded-lg border border-border shadow-sm">
                      {param.result}
                    </span>
                  </td>
                  <td className="p-6">
                    <ConfidenceBar percent={param.confidencePercent} status={param.status} />
                  </td>
                  <td className="p-6">
                    <StatusBadge status={param.status} showIcon={false} />
                  </td>
                  <td className="p-6 text-sm text-muted-foreground max-w-xs leading-relaxed">
                    {param.status === "ok" ? (
                      <span className="opacity-50">Normal parameters</span>
                    ) : (
                      <span className={param.status === 'critical' ? 'text-destructive-foreground/80 font-medium' : 'text-warning'}>
                        {param.explanation}
                      </span>
                    )}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </Layout>
  );
}
