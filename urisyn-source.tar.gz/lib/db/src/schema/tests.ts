import { pgTable, serial, integer, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { patientsTable } from "./patients";

export const testParameterSchema = z.object({
  pad: z.string(),
  result: z.string(),
  confidencePercent: z.number().int(),
  status: z.enum(["ok", "mild", "critical"]),
  explanation: z.string().nullable().optional(),
});

export type TestParameter = z.infer<typeof testParameterSchema>;

export const urinalysisTestsTable = pgTable("urinalysis_tests", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => patientsTable.id).notNull(),
  testDate: text("test_date").notNull(),
  overallStatus: text("overall_status").notNull(),
  recommendation: text("recommendation").notNull(),
  parameters: jsonb("parameters").notNull().$type<TestParameter[]>(),
  notes: text("notes"),
  obsFileKey: text("obs_file_key"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTestSchema = createInsertSchema(urinalysisTestsTable).omit({ id: true, createdAt: true });
export type InsertTest = z.infer<typeof insertTestSchema>;
export type UrinalysisTest = typeof urinalysisTestsTable.$inferSelect;
